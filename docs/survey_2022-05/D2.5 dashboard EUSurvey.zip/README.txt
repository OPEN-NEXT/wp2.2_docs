Both files are the same survey, but with very minor differences in implementation details.

`open-next-validation-workshop-2022.eus` has the introduction tweaked for the D3.5 validation day to fit that day's agenda.

`WIF-improvements.eus` is the same survey, but the one that was distributed to Wikifactory users and other venues.
